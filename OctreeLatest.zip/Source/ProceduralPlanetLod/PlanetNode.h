// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "ProceduralMeshComponent.h"
#include "Components/BoxComponent.h"
#include "PlanetNode.generated.h"


UENUM(BlueprintType)		//"BlueprintType" is essential to include
enum class EEntityTypeEnum : uint8
{
	Planet 	UMETA(DisplayName = "Planet"),
	Asteroid 	UMETA(DisplayName = "Asteroid")
	
};

UCLASS()
class PROCEDURALPLANETLOD_API APlanetNode : public AActor
{
	GENERATED_BODY()

public:
	// Sets default values for this actor's properties
	APlanetNode();

protected:
	// Called when the game starts or when spawned
	virtual void BeginPlay() override;

public:
	// Called every frame
	virtual void Tick(float DeltaTime) override;

	// Called in editor
	virtual void PostActorCreated() override;

	//Called when a property is changed
	virtual void PostEditChangeProperty(FPropertyChangedEvent & PropertyChangedEvent);

	// Node box component
	UPROPERTY(BlueprintReadWrite, EditAnywhere, Category = "Defaults")
		UBoxComponent * BoxVisual;

	// Create our procedural mesh component
	UPROPERTY(BlueprintReadWrite, EditAnywhere, Category = "Defaults")
		UProceduralMeshComponent * PlanetNodeMesh;

	// The player's current position
	UPROPERTY(BlueprintReadWrite, EditAnywhere, Category = "Defaults")
		FVector PlayerPos;

	// Within bounds boolean
	UPROPERTY(BlueprintReadWrite, EditAnywhere, Category = "Defaults")
		bool InBounds;

	// Amount of times to subdivide
	UPROPERTY(BlueprintReadWrite, EditAnywhere, Category = "Defaults", meta = (ExposeOnSpawn = true))
		int32 Recursions;

	// The player's distance from this terrain node
	UPROPERTY(BlueprintReadWrite, EditAnywhere, Category = "Defaults", meta = (ExposeOnSpawn = true))
		float DistFromPlanetNode;


	// The size of this terrain node
	UPROPERTY(BlueprintReadWrite, EditAnywhere, Category = "Defaults", meta = (ExposeOnSpawn = true))
		float PlanetNodeScale;

	// The parent of this node
	UPROPERTY(BlueprintReadWrite, EditAnywhere, Category = "Defaults", meta = (ExposeOnSpawn = true))
		APlanetNode * ParentNodeRef;



	// The size of this terrain node
	UPROPERTY(BlueprintReadWrite, EditAnywhere, Category = "Defaults", meta = (ExposeOnSpawn = true))
		float DefaultPlanetNodeScale;


	// Variables from the Planet Class

	UPROPERTY(BlueprintReadWrite, EditAnywhere, Category = "Defaults", meta = (ExposeOnSpawn = true))
		TArray<FVector> PlanetVertices;
	UPROPERTY(BlueprintReadWrite, EditAnywhere, Category = "Defaults", meta = (ExposeOnSpawn = true))
		TArray<int32> PlanetTriangles;
	UPROPERTY(BlueprintReadWrite, EditAnywhere, Category = "Defaults", meta = (ExposeOnSpawn = true))
		FVector PlanetLocation;


	// Variables for the Planet node mesh component
	UPROPERTY(BlueprintReadWrite, EditAnywhere, Category = "Defaults")
		TArray<FVector> Vertices;
	UPROPERTY(BlueprintReadWrite, EditAnywhere, Category = "Defaults")
		TArray<int32> Triangles;
	TArray<FVector> Normals;
	TArray<FVector2D> UV0;
	TArray<FLinearColor> VertexColors;
	TArray<FColor> UpVertexColors;
	TArray<FProcMeshTangent> Tangents;

	// Variables for subdivision
	TArray<FVector> Vertices_New;
	TArray<int32> Triangles_New;
	int32 IndexA, IndexB, IndexC;

	// Indexes to use when seeking internal triangles
	int32 ia, ib, ic, nia, nib, nic;

	UFUNCTION(BlueprintCallable, Category = "Defaults")
		void SeekInternalTris();


	//Check within bounds
	void CheckPlayerInBounds();


	// Handle Subdivision count
	UFUNCTION(BlueprintCallable, Category = "Defaults")
		void HandleSubdivision();

	//Rebuild triangle list
	void BuildTriangleList();

	//Do the actual subdivision
	void Subdivide(int32 a, int32 b, int32 c);


	// Perform a noise check for the vertices
	UFUNCTION(BlueprintCallable, Category = "Defaults")
		void DoNoise();


	// Calculate vertex normals
	UFUNCTION(BlueprintCallable, Category = "Defaults")
		void CalculateNormals();




	// Displacement points
	UPROPERTY(BlueprintReadWrite, EditAnywhere, Category = "Defaults", meta = (ExposeOnSpawn = true))
		TArray<FVector> DisplacePoints;

	UPROPERTY(BlueprintReadWrite, EditAnywhere, Category = "Defaults", meta = (ExposeOnSpawn = true))
		float DistFromNoisePoint;

	UPROPERTY(BlueprintReadWrite, EditAnywhere, Category = "Defaults", meta = (ExposeOnSpawn = true))
		float NoiseScale;

	UPROPERTY(BlueprintReadWrite, EditAnywhere, Category = "Defaults", meta = (ExposeOnSpawn = true))
		float BorderEdgeFalloff;

	UPROPERTY(BlueprintReadWrite, EditAnywhere, Category = "Defaults", meta = (ExposeOnSpawn = true))
		float NoiseIntensityScale;

	UPROPERTY(BlueprintReadWrite, EditAnywhere, Category = "Defaults", meta = (ExposeOnSpawn = true))
		float CustomNoiseScale;

	UPROPERTY(BlueprintReadWrite, EditAnywhere, Category = "Defaults", meta = (ExposeOnSpawn = true))
		int NodeSplitCount;

	UPROPERTY(BlueprintReadWrite, EditAnywhere, Category = "Defaults", meta = (ExposeOnSpawn = true))
		int MaxSplits;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Defaults")
		EEntityTypeEnum EntityType;

	
	
};


