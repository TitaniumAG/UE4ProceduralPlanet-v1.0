// Fill out your copyright notice in the Description page of Project Settings.

#include "PlanetNode.h" 


// Sets default values
APlanetNode::APlanetNode()
{
	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;

	// Add root component
	RootComponent = CreateAbstractDefaultSubobject<USceneComponent>(TEXT("RootComponent"));

	// Add procedural mesh component 
	PlanetNodeMesh = CreateDefaultSubobject<UProceduralMeshComponent>(TEXT("TerrainMesh"));

	// Attach the procedural mesh component to the root
	PlanetNodeMesh->AttachTo(RootComponent);

	// Box node 1
	BoxVisual = CreateDefaultSubobject<UBoxComponent>(TEXT("boxNode1"));
	BoxVisual->AttachTo(RootComponent);

	// set our subdivision search index values
	IndexA = 0;
	IndexB = 1;
	IndexC = 2;

	// set our triangle search index values 
	ia = 0;
	ib = 1;
	ic = 2;

	


}

// Called in editor
void APlanetNode::PostActorCreated()
{
	Super::PostActorCreated();


}



//Called when a property is changed
void APlanetNode::PostEditChangeProperty(struct FPropertyChangedEvent& PropertyChangedEvent)
{
	Super::PostEditChangeProperty(PropertyChangedEvent);

	BoxVisual->SetBoxExtent(FVector(PlanetNodeScale, PlanetNodeScale, PlanetNodeScale));


	

}

// Called when the game starts or when spawned
void APlanetNode::BeginPlay()
{
	Super::BeginPlay();

	BoxVisual->SetBoxExtent(FVector(PlanetNodeScale, PlanetNodeScale, PlanetNodeScale));

}

// Called every frame
void APlanetNode::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

	CheckPlayerInBounds();

}

void APlanetNode::SeekInternalTris()
{
		// look for and add internal triangles
	for (int i = 0; i < PlanetTriangles.Num() / 3; i++)
	{
		FVector a, b, c, ab, bc, ca, avg;

		a = PlanetVertices[PlanetTriangles[ia]];
		b = PlanetVertices[PlanetTriangles[ib]];
		c = PlanetVertices[PlanetTriangles[ic]];
		ab = FMath::Lerp(a, b, 0.5);
		bc = FMath::Lerp(a, b, 0.5);
		ca = FMath::Lerp(a, b, 0.5);
		

		avg = (a + b + c) / 3;
		
		// seems pretty stable! 
		/*if (avg.X + PlanetLocation.X < GetActorLocation().X + (PlanetNodeScale + BorderEdgeFalloff) &&
				avg.X + PlanetLocation.X > GetActorLocation().X - (PlanetNodeScale + BorderEdgeFalloff) &&
				avg.Y + PlanetLocation.Y < GetActorLocation().Y + (PlanetNodeScale + BorderEdgeFalloff) &&
				avg.Y + PlanetLocation.Y > GetActorLocation().Y - (PlanetNodeScale + BorderEdgeFalloff) &&
				avg.Z + PlanetLocation.Z < GetActorLocation().Z + (PlanetNodeScale + BorderEdgeFalloff) &&
				avg.Z + PlanetLocation.Z > GetActorLocation().Z - (PlanetNodeScale + BorderEdgeFalloff))*/


		// endpoints
			if (avg.X + PlanetLocation.X < GetActorLocation().X + (PlanetNodeScale + BorderEdgeFalloff) &&
				avg.X + PlanetLocation.X > GetActorLocation().X - (PlanetNodeScale + BorderEdgeFalloff) &&
				avg.Y + PlanetLocation.Y < GetActorLocation().Y + (PlanetNodeScale + BorderEdgeFalloff) &&
				avg.Y + PlanetLocation.Y > GetActorLocation().Y - (PlanetNodeScale + BorderEdgeFalloff) &&
				avg.Z + PlanetLocation.Z < GetActorLocation().Z + (PlanetNodeScale + BorderEdgeFalloff) &&
				avg.Z + PlanetLocation.Z > GetActorLocation().Z - (PlanetNodeScale + BorderEdgeFalloff))
				
			{
				Vertices.Add(a);
				Vertices.Add(b);
				Vertices.Add(c);
			}

			ia = ia + 3;
			ib = ib + 3;
			ic = ic + 3;
		}

		

	
	Triangles.Empty();

	for (int i = 0; i < Vertices.Num(); i++)
	{
		Triangles.Add(i);
	}

	
	PlanetNodeMesh->SetWorldLocation(PlanetLocation);
	PlanetNodeMesh->CreateMeshSection_LinearColor(0, Vertices, Triangles, Normals, UV0, VertexColors, Tangents, true);
}



void APlanetNode::CheckPlayerInBounds()
{
	/*
	if (PlayerPos.X < PlanetNodeMesh->GetComponentLocation().X + PlanetNodeScale&&
	PlayerPos.X > PlanetNodeMesh->GetComponentLocation().X - PlanetNodeScale &&
	PlayerPos.Y < PlanetNodeMesh->GetComponentLocation().Y + PlanetNodeScale &&
	PlayerPos.Y > PlanetNodeMesh->GetComponentLocation().Y - PlanetNodeScale &&
	PlayerPos.Z < PlanetNodeMesh->GetComponentLocation().Z + PlanetNodeScale &&
	PlayerPos.Z > PlanetNodeMesh->GetComponentLocation().Z - PlanetNodeScale )
	{
	InBounds = true;
	}
	else
	{
	InBounds = false;
	}
	*/
	
	
	if (FVector(PlayerPos - BoxVisual->GetComponentLocation()).Size() < DistFromPlanetNode)
	{
		InBounds = true;
		//PlanetNodeMesh->CastShadow = true;
	}
	else
	{
		
			InBounds = false;
			//PlanetNodeMesh->CastShadow = false;
	}
	
}


void APlanetNode::Subdivide(int32 a, int32 b, int32 c)
{
	FVector va, vb, vc, vab, vbc, vca;


	va = Vertices[a];
	vb = Vertices[b];
	vc = Vertices[c];

	vab = FMath::Lerp(va, vb, 0.5);
	vbc = FMath::Lerp(vb, vc, 0.5);
	vca = FMath::Lerp(vc, va, 0.5);

	/*
	// make it more rounded
	va.Normalize();
	vb.Normalize();
	vc.Normalize();
	vab.Normalize();
	vbc.Normalize();
	vca.Normalize();

	// scale it back up // DefaultTerrainNodeScale
	va = va * DefaultPlanetNodeScale;
	vb = vb * DefaultPlanetNodeScale;
	vc = vc * DefaultPlanetNodeScale;
	vab = vab * DefaultPlanetNodeScale;
	vbc = vbc * DefaultPlanetNodeScale;
	vca = vca * DefaultPlanetNodeScale;
	*/

	/*
	if (DisplacePoints.Num() > 0)
	{
		for (int i = 0; i < DisplacePoints.Num(); i++)
		{
			if (FVector((va + TerrainLocation) - DisplacePoints[i]).Size() < DistFromNoisePoint)
			{
				va = va * NoiseScale;
			}
			if (FVector((vb + TerrainLocation) - DisplacePoints[i]).Size() < DistFromNoisePoint)
			{
				vb = vb * NoiseScale;
			}
			if (FVector((vc + TerrainLocation) - DisplacePoints[i]).Size() < DistFromNoisePoint)
			{
				vc = vc * NoiseScale;
			}

			if (FVector((vab + TerrainLocation) - DisplacePoints[i]).Size() < DistFromNoisePoint)
			{
				vab = vab * NoiseScale;
			}
			if (FVector((vbc + TerrainLocation) - DisplacePoints[i]).Size() < DistFromNoisePoint)
			{
				vbc = vbc * NoiseScale;
			}
			if (FVector((vca + TerrainLocation) - DisplacePoints[i]).Size() < DistFromNoisePoint)
			{
				vca = vca * NoiseScale;
			}
		}
	}
	*/






	// custom noise...
	vab = vab * CustomNoiseScale;
	vbc = vbc * CustomNoiseScale;
	vca = vca * CustomNoiseScale;



	Vertices_New.Add(va);
	Vertices_New.Add(vab);
	Vertices_New.Add(vca);

	Vertices_New.Add(vca); 
	Vertices_New.Add(vbc);
	Vertices_New.Add(vc);

	Vertices_New.Add(vab);
	Vertices_New.Add(vb);
	Vertices_New.Add(vbc);

	Vertices_New.Add(vab);
	Vertices_New.Add(vbc); 
	Vertices_New.Add(vca); 




	IndexA = IndexA + 3;
	IndexB = IndexB + 3;
	IndexC = IndexC + 3;

}

void APlanetNode::BuildTriangleList()
{

	for (int i = 0; i < Vertices.Num(); i++)
	{
		// Build vertecx index list
		Triangles.Add(i);
	}
}

void APlanetNode::HandleSubdivision()
{
	// add some interesting noise to the geometry
	if (NodeSplitCount == 1)
	{
		CustomNoiseScale = CustomNoiseScale  - 0.0007;
	}
	if (NodeSplitCount == 2)
	{
		CustomNoiseScale = CustomNoiseScale - 0.0005;
	}
	if (NodeSplitCount == 3)
	{
		CustomNoiseScale = CustomNoiseScale - 0.0003;
	}
	if (NodeSplitCount == 4)
	{
		CustomNoiseScale = CustomNoiseScale + 0.0007;
	}
	if (NodeSplitCount == 5)
	{
		CustomNoiseScale = CustomNoiseScale + 0.0003;
	}
	 

	// Keep subdivisions at a safe level! 
	if (Recursions > 5)
	{
		Recursions = 5;
	}


	// Handle the subdivisions
	for (int i = 0; i < Recursions; i++)
	{

		for (int j = 0; j < Triangles.Num() / 3; j++)
		{
			Subdivide(Triangles[IndexA], Triangles[IndexB], Triangles[IndexC]);
		}

		// Empty
		Vertices.Empty();
		Triangles.Empty();



		//Assign new to current
		Vertices = Vertices_New;


		//New empty 
		Vertices_New.Empty();
		VertexColors.Empty();

		//Build tri indices
		BuildTriangleList();


		//Reset index counters 
		IndexA = 0;
		IndexB = 1;
		IndexC = 2;


	}

	// set our normal index values 
	nia = 0;
	nib = 1;
	nic = 2;

	// calculate normals
	for (int i = 0; i < Triangles.Num() / 3; i++)
	{
		// create variables to store normals
		FVector na, nb, nc, n;



		na = Vertices[Triangles[nia]];
		nb = Vertices[Triangles[nib]];
		nc = Vertices[Triangles[nic]];



		//FVector NormalCurrent = FVector::CrossProduct(na - nb, na - nc);
		//NormalCurrent.Normalize();


		// cross product calculation for normals...
		//n.X = na.Y + nb.Z + na.Z + nc.Y;
		//n.Y = na.Z + nb.X + na.X + nc.Z;
		//n.Z = na.X + nb.Y + na.Y + nc.X;
		//n.Normalize();

		na.Normalize();
		nb.Normalize();
		nc.Normalize();


		Normals.Add(na);
		Normals.Add(nb);
		Normals.Add(nc);

		nia = nia + 3;
		nib = nib + 3;
		nic = nic + 3;



	}
	if (EntityType == EEntityTypeEnum::Planet)
	{
		// lets  blend the current sphere shape with a normalized one 
		for (int i = 0; i < Vertices.Num(); i++)
		{
			FVector v;
			v = Vertices[i];
			v.Normalize();
			v = v * DefaultPlanetNodeScale;
			Vertices[i] = FMath::Lerp(Vertices[i], v, 0.5);
		}
	}
	PlanetNodeMesh->CreateMeshSection_LinearColor(0, Vertices, Triangles, Normals, UV0, VertexColors, Tangents, true);
	PlanetNodeMesh->SetWorldLocation(PlanetLocation);
	

	DoNoise();

	

	
}


void APlanetNode::DoNoise()
{
	// Check vertex distance from noise points
	for (int i = 0; i < Vertices.Num(); i++)
	{
		for (int j = 0; j < DisplacePoints.Num(); j++)
		{
			if (FVector(Vertices[i] - DisplacePoints[j]).Size() < DistFromNoisePoint)
			{
				Vertices[i] = Vertices[i] * NoiseIntensityScale;
			}

		}

	}

	PlanetNodeMesh->UpdateMeshSection(0, Vertices, Normals, UV0, UpVertexColors, Tangents);
}




void APlanetNode::CalculateNormals()
{

	int32 nia, nib, nic;
	nia = 0;
	nib = 1;
	nic = 2;

	Normals.Empty();
	for (int32 i = 0; i < Triangles.Num() / 3; i++)
	{

		FVector a, b, c, n, na, nb, nc, avg;

		a = Vertices[Triangles[nia]];
		b = Vertices[Triangles[nib]];
		c = Vertices[Triangles[nic]];

		a.Normalize();
		b.Normalize();
		c.Normalize();


		Normals.Add(a);
		Normals.Add(b);
		Normals.Add(c);


		nia = nia + 3;
		nib = nib + 3;
		nic = nic + 3;



	}
	PlanetNodeMesh->UpdateMeshSection(0, Vertices, Normals, UV0, UpVertexColors, Tangents);
}

