// Fill out your copyright notice in the Description page of Project Settings.

#include "Planet.h"


// Sets default values
APlanet::APlanet()
{
	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;

	// Add root component
	RootComponent = CreateAbstractDefaultSubobject<USceneComponent>(TEXT("RootComponent"));

	// Add procedural mesh component 
	PlanetMesh = CreateDefaultSubobject<UProceduralMeshComponent>(TEXT("PlanetMesh"));

	// Attach the procedural mesh component to the root
	PlanetMesh->AttachTo(RootComponent);

	// Set the terrain scale value
	PlanetScale = 500;

	CustomNoiseScale = 1;

	NoiseIntensityScale = 100;

	DistFromPointScale = 500;

	// Set the subdivision search index values
	IndexA = 0;
	IndexB = 1;
	IndexC = 2;
	


}


// Called in editor
void APlanet::PostActorCreated()
{
	Super::PostActorCreated();

	
		
}



//Called when a property is changed
void APlanet::PostEditChangeProperty(struct FPropertyChangedEvent& PropertyChangedEvent)
{
	Super::PostEditChangeProperty(PropertyChangedEvent);
	
	//GenerateMesh();

}


// Called when the game starts or when spawned
void APlanet::BeginPlay()
{
	Super::BeginPlay();
}

// Called every frame
void APlanet::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

	

}

void APlanet::GenerateMesh()
{
	HandleSubdivision();
	
		// Map cube to sphere
		for (int i = 0; i < Vertices.Num(); i++)
		{
			Vertices[i].Normalize();
			Vertices[i] = Vertices[i] * PlanetScale;
		}
		
		PlanetMesh->CreateMeshSection_LinearColor(0, Vertices, Triangles, Normals, UV0, VertexColors, Tangents, true);

		

		DoNoise();
	

}

void APlanet::Subdivide(int32 a, int32 b, int32 c)
{
	FVector va, vb, vc, vab, vbc, vca;

	PlanetSplitCount++;

	va = Vertices[a];
	vb = Vertices[b];
	vc = Vertices[c];

	vab = FMath::Lerp(va, vb, 0.5);
	vbc = FMath::Lerp(vb, vc, 0.5);
	vca = FMath::Lerp(vc, va, 0.5);
	



	// custom noise...
	vab = vab * CustomNoiseScale;
	vbc = vbc * CustomNoiseScale;
	vca = vca * CustomNoiseScale;


	Vertices_New.Add(va);
	Vertices_New.Add(vab);
	Vertices_New.Add(vca);

	Vertices_New.Add(vca);
	Vertices_New.Add(vbc);
	Vertices_New.Add(vc);

	Vertices_New.Add(vab);
	Vertices_New.Add(vb);
	Vertices_New.Add(vbc);

	Vertices_New.Add(vab);
	Vertices_New.Add(vbc);
	Vertices_New.Add(vca);



	IndexA = IndexA + 3;
	IndexB = IndexB + 3;
	IndexC = IndexC + 3;

}

void APlanet::BuildTriangleList()
{

	for (int i = 0; i < Vertices.Num(); i++)
	{
		// Build vertecx index list
		Triangles.Add(i);
	}
}


void APlanet::HandleSubdivision()
{
	Vertices = {
		FVector(-100,	-100,	-100),
		FVector(-100,	-100,	100),
		FVector(-100,	100,	-100),
		FVector(-100,	100,	100),
		FVector(100,	-100,	-100),
		FVector(100,	-100,	100),
		FVector(100,	100,	-100),
		FVector(100,	100,	100) };

	Triangles = {
		0	,	2	,	1	,
		2	,	6	,	3	,
		6	,	4	,	7	,
		4	,	0	,	5	,
		2	,	0	,	6	,
		7	,	5	,	3	,
		2	,	3	,	1	,
		6	,	7	,	3	,
		4	,	5	,	7	,
		0	,	1	,	5	,
		0	,	4	,	6	,
		5	,	1	,	3 };

	// Keep subdivisions at a safe level! 
	if (Recursions > 10)
	{
		Recursions = 10;
	}

	// Handle the subdivisions
	for (int i = 0; i < Recursions; i++)
	{
		

		for (int j = 0; j < Triangles.Num() / 3; j++)
		{

			Subdivide(Triangles[IndexA], Triangles[IndexB], Triangles[IndexC]);
		}

		// Empty
		Vertices.Empty();
		Triangles.Empty();


		//Assign new to current
		Vertices = Vertices_New;

		//Build tri indices
		BuildTriangleList();

		//New empty 
		Vertices_New.Empty();


		


		//Reset index counters 
		IndexA = 0;
		IndexB = 1;
		IndexC = 2;


	}

	//PlanetMesh->CreateMeshSection_LinearColor(0, Vertices, Triangles, Normals, UV0, VertexColors, Tangents, true);
	//TerrainMesh->SetWorldLocation(RootComponent->GetComponentLocation() + (GetActorUpVector() / -1) * TerrainScale);
}



void APlanet::DoNoise()
{
	// Clear noise vectors
	DisplacePoints.Empty();

	NoiseScale = PlanetScale;
	DistFromPointScale = PlanetScale/2;

	// lets create our noise vectors 
	for (int i = 0; i < DisplacementPointCount; i++)
	{
		DisplacePoints.Add(FMath::VRand()*FMath::FRandRange(NoiseScale/2,NoiseScale));
	}

/*

	for (int i = 0; i < DisplacePoints.Num(); i++)
	{		;
		DisplacePoints[i] = DisplacePoints[i] * NoiseScale;
	}
	*/

	
	
	if (DisplacePoints.Num() > 0)
	{
		// Check vertex distance from noise points
		for (int i = 0; i < Vertices.Num(); i++)
		{
			for (int j = 0; j < DisplacePoints.Num(); j++)
			{
				if (FVector(Vertices[i] - DisplacePoints[j]).Size() < DistFromPointScale)
				{
					Vertices[i] = Vertices[i]*NoiseIntensityScale;
				}

			}

		}

		PlanetMesh->UpdateMeshSection(0, Vertices, Normals, UV0, UpVertexColors, Tangents);
	}
}


void APlanet::CalculateNormals()
{

	int32 nia, nib, nic;
	nia = 0;
	nib = 1;
	nic = 2;

	Normals.Empty();
	for (int32 i = 0; i < Triangles.Num() / 3; i++)
	{

		FVector a, b, c, n, na, nb, nc, avg;

		a = Vertices[Triangles[nia]];
		b = Vertices[Triangles[nib]];
		c = Vertices[Triangles[nic]];

		a.Normalize();
		b.Normalize();
		c.Normalize();
		

		Normals.Add(a);
		Normals.Add(b);
		Normals.Add(c);


		nia = nia + 3;
		nib = nib + 3;
		nic = nic + 3;

		
		
	}
	PlanetMesh->UpdateMeshSection(0, Vertices, Normals, UV0, UpVertexColors, Tangents);
}