// Fill out your copyright notice in the Description page of Project Settings.

#include "Planet.h"


// Sets default values
APlanet::APlanet()
{
	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;

	// Add root component
	RootComponent = CreateAbstractDefaultSubobject<USceneComponent>(TEXT("RootComponent"));

	// Add procedural mesh component 
	PlanetMesh = CreateDefaultSubobject<UProceduralMeshComponent>(TEXT("PlanetMesh"));

	// Attach the procedural mesh component to the root
	PlanetMesh->AttachTo(RootComponent);

	// Set the terrain scale value
	PlanetScale = 500;

	


}


// Called in editor
void APlanet::PostActorCreated()
{
	Super::PostActorCreated();
	/*
	Vertices = {
		FVector(-100,	-100,	-100),
		FVector(-100,	-100,	100),
		FVector(-100,	100,	-100),
		FVector(-100,	100,	100),
		FVector(100,	-100,	-100),
		FVector(100,	-100,	100),
		FVector(100,	100,	-100),
		FVector(100,	100,	100) };

	Triangles = {
		0	,	2	,	1	,
		2	,	6	,	3	,
		6	,	4	,	7	,
		4	,	0	,	5	,
		2	,	0	,	6	,
		7	,	5	,	3	,
		2	,	3	,	1	,
		6	,	7	,	3	,
		4	,	5	,	7	,
		0	,	1	,	5	,
		0	,	4	,	6	,
		5	,	1	,	3 };
	*/
	//PlanetMesh->CreateMeshSection_LinearColor(0, Vertices, Triangles, Normals, UV0, VertexColors, Tangents, true);
}



//Called when a property is changed
void APlanet::PostEditChangeProperty(struct FPropertyChangedEvent& PropertyChangedEvent)
{
	Super::PostEditChangeProperty(PropertyChangedEvent);
	/*
	Vertices = {
		FVector(-100,	-100,	-100),
		FVector(-100,	-100,	100),
		FVector(-100,	100,	-100),
		FVector(-100,	100,	100),
		FVector(100,	-100,	-100),
		FVector(100,	-100,	100),
		FVector(100,	100,	-100),
		FVector(100,	100,	100) };

	Triangles = {
		0	,	2	,	1	,
		2	,	6	,	3	,
		6	,	4	,	7	,
		4	,	0	,	5	,
		2	,	0	,	6	,
		7	,	5	,	3	,
		2	,	3	,	1	,
		6	,	7	,	3	,
		4	,	5	,	7	,
		0	,	1	,	5	,
		0	,	4	,	6	,
		5	,	1	,	3 };
		*/

	/*
	// Map cube to sphere
	for (int i = 0; i < Vertices.Num(); i++)
	{
		Vertices[i].GetSafeNormal(1.0f);
		Vertices[i].Normalize(1.0f);
		Vertices[i] = Vertices[i] * PlanetScale;

	}
	*/

	//PlanetMesh->CreateMeshSection_LinearColor(0, Vertices, Triangles, Normals, UV0, VertexColors, Tangents, true);

}

// Called when the game starts or when spawned
void APlanet::BeginPlay()
{
	Super::BeginPlay();
}

// Called every frame
void APlanet::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

	

}

void APlanet::GenerateMesh()
{
	/*
	Vertices = {
		FVector(-100,	-100,	-100),
		FVector(-100,	-100,	100),
		FVector(-100,	100,	-100),
		FVector(-100,	100,	100),
		FVector(100,	-100,	-100),
		FVector(100,	-100,	100),
		FVector(100,	100,	-100),
		FVector(100,	100,	100) };

	Triangles = {
		0	,	2	,	1	,
		2	,	6	,	3	,
		6	,	4	,	7	,
		4	,	0	,	5	,
		2	,	0	,	6	,
		7	,	5	,	3	,
		2	,	3	,	1	,
		6	,	7	,	3	,
		4	,	5	,	7	,
		0	,	1	,	5	,
		0	,	4	,	6	,
		5	,	1	,	3 };

		*/

	/*
	// Map cube to sphere
	for (int i = 0; i < Vertices.Num(); i++)
	{
		Vertices[i].GetSafeNormal(1.0f);
		Vertices[i].Normalize(1.0f);
		Vertices[i] = Vertices[i] * PlanetScale;

	}
	*/

	PlanetMesh->CreateMeshSection_LinearColor(0, Vertices, Triangles, Normals, UV0, VertexColors, Tangents, true);
	
	//DoNoise();
}

void APlanet::Subdivide(int32 a, int32 b, int32 c)
{
	FVector va, vb, vc, vab, vbc, vca, nva, nvb, nvc, nvab, nvbc, nvca;


	va = Vertices[a];
	vb = Vertices[b];
	vc = Vertices[c];

	vab = FMath::Lerp(va, vb, 0.5);
	vbc = FMath::Lerp(vb, vc, 0.5);
	vca = FMath::Lerp(vc, va, 0.5);


	// custom noise...
	//vab = vab + FVector(0,0,7);
	//vbc = vbc + FVector(0, 0, 7);
	//vca = vca + FVector(0, 0, 7);




	/*
	if (DisplacePoints.Num() > 0)
	{
		for (int i = 0; i < DisplacePoints.Num(); i++)
		{
			if (FVector(va + GetActorLocation() - DisplacePoints[i]).Size() < DistFromPoint)
			{
				va = va * NoiseScale;
			}
			if (FVector(vb + GetActorLocation() - DisplacePoints[i]).Size() < DistFromPoint)
			{
				vb = vb * NoiseScale;
			}
			if (FVector(vc + GetActorLocation() - DisplacePoints[i]).Size() < DistFromPoint)
			{
				vc = vc * NoiseScale;
			}

			if (FVector(vab + GetActorLocation() - DisplacePoints[i]).Size() < DistFromPoint)
			{
				vab = vab * NoiseScale;
			}
			if (FVector(vbc + GetActorLocation() - DisplacePoints[i]).Size() < DistFromPoint)
			{
				vbc = vbc * NoiseScale;
			}
			if (FVector(vca + GetActorLocation() - DisplacePoints[i]).Size() < DistFromPoint)
			{
				vca = vca * NoiseScale;
			}
		}
	}
	*/
	/*
	// a clone of our current vertex data
	nva = va;
	nvb = vb;
	nvc = vc;
	nvab = vab;
	nvbc = vbc;
	nvca = vca;

	// normalized clone of our original vertices 
	nva.Normalize();
	nvb.Normalize();
	nvc.Normalize();
	nvab.Normalize();
	nvbc.Normalize();
	nvca.Normalize();

	// lets scale them back up
	nva = nva * PlanetScale;
	nvb = nvb * PlanetScale;
	nvc = nvc * PlanetScale;
	nvab = nvab * PlanetScale;
	nvbc = nvbc * PlanetScale;
	nvca = nvca * PlanetScale;

	// make it partly rounded
	va = FMath::Lerp(nva, va, 0.5);
	vb = FMath::Lerp(nvb, vb, 0.5);
	vc = FMath::Lerp(nvc, vc, 0.5);
	vab = FMath::Lerp(nvab, vab, 0.5);
	vbc = FMath::Lerp(nvbc, vbc, 0.5);
	vca = FMath::Lerp(nvca, vca, 0.5);
	*/


	// custom noise...
	//vab = vab * TerrainScale;
	//vbc = vbc * TerrainScale;
	//vca = vca * TerrainScale;


	Vertices_New.Add(va);
	Vertices_New.Add(vab);
	Vertices_New.Add(vca);

	Vertices_New.Add(vca);
	Vertices_New.Add(vbc);
	Vertices_New.Add(vc);

	Vertices_New.Add(vab);
	Vertices_New.Add(vb);
	Vertices_New.Add(vbc);

	Vertices_New.Add(vab);
	Vertices_New.Add(vbc);
	Vertices_New.Add(vca);


	IndexA = IndexA + 3;
	IndexB = IndexB + 3;
	IndexC = IndexC + 3;

}

void APlanet::BuildTriangleList()
{

	for (int i = 0; i < Vertices.Num(); i++)
	{
		// Build vertecx index list
		Triangles.Add(i);
	}
}

void APlanet::HandleSubdivision()
{
	// Keep subdivisions at a safe level! 
	if (Recursions > 5)
	{
		Recursions = 5;
	}
		



	// Handle the subdivisions
	for (int i = 0; i < Recursions; i++)
	{
		//Reset index counters 
		IndexA = 0;
		IndexB = 1;
		IndexC = 2;

		for (int j = 0; j < Triangles.Num() / 3; j++)
		{

			Subdivide(Triangles[IndexA], Triangles[IndexB], Triangles[IndexC]);
		}

		// Empty
		Vertices.Empty();
		Triangles.Empty();



		//Assign new to current
		Vertices = Vertices_New;


		//New empty 
		Vertices_New.Empty();
		VertexColors.Empty();

		//Build tri indices
		BuildTriangleList();


		


	}
}



void APlanet::DoNoise()
{
	if (DisplacePoints.Num() > 0)
	{
		// Check vertex distance from noise points
		for (int i = 0; i < Vertices.Num(); i++)
		{
			for (int j = 0; j < DisplacePoints.Num(); j++)
			{
				if (FVector(Vertices[i] + PlanetLocation - DisplacePoints[j]).Size() < DistFromPoint)
				{
					Vertices[i] = Vertices[i] * NoiseIntensity;
				}

			}

		}

		PlanetMesh->UpdateMeshSection(0, Vertices, Normals, UV0, UpVertexColors, Tangents);
	}
}