// Fill out your copyright notice in the Description page of Project Settings.

#include "Terrain.h"


// Sets default values
ATerrain::ATerrain()
{
	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;

	// Add root component
	RootComponent = CreateAbstractDefaultSubobject<USceneComponent>(TEXT("RootComponent"));

	// Add procedural mesh component 
	TerrainMesh = CreateDefaultSubobject<UProceduralMeshComponent>(TEXT("TerrainMesh"));

	// Attach the procedural mesh component to the root
	TerrainMesh->AttachTo(RootComponent);

	// Set the terrain scale value
	TerrainScale = 500;

	// Set the search index values
	IndexA = 0;
	IndexB = 1;
	IndexC = 2;


}


// Called in editor
void ATerrain::PostActorCreated()
{
	Super::PostActorCreated();
	/*
	// Add vertices
	Vertices.Add(FVector(-TerrainScale, -TerrainScale, 0));
	Vertices.Add(FVector(-TerrainScale, TerrainScale, 0));
	Vertices.Add(FVector(TerrainScale, -TerrainScale, 0));
	Vertices.Add(FVector(TerrainScale, TerrainScale, 0));

	Triangles.Add(0);
	Triangles.Add(1);
	Triangles.Add(2);

	Triangles.Add(2);
	Triangles.Add(1);
	Triangles.Add(3);

	TerrainMesh->CreateMeshSection_LinearColor(0, Vertices, Triangles, Normals, UV0, VertexColors, Tangents, false);
	*/

}



//Called when a property is changed
void ATerrain::PostEditChangeProperty(struct FPropertyChangedEvent& PropertyChangedEvent)
{
	Super::PostEditChangeProperty(PropertyChangedEvent);

	GenerateMesh();

}

// Called when the game starts or when spawned
void ATerrain::BeginPlay()
{
	Super::BeginPlay();
}

// Called every frame
void ATerrain::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

	CheckPlayerInBounds();

}

void ATerrain::GenerateMesh()
{
	HandleSubdivision();

	// Map cube to sphere
	for (int i = 0; i < Vertices.Num(); i++)
	{
		Vertices[i].GetSafeNormal(1.0f);
		Vertices[i].Normalize(1.0f);
		Vertices[i] = Vertices[i] * TerrainScale;

	}


	TerrainMesh->CreateMeshSection_LinearColor(0, Vertices, Triangles, Normals, UV0, VertexColors, Tangents, true);

	DoNoise();
}

void ATerrain::Subdivide(int32 a, int32 b, int32 c)
{
	FVector va, vb, vc, vab, vbc, vca, nva, nvb, nvc, nvab, nvbc, nvca;


	va = Vertices[a];
	vb = Vertices[b];
	vc = Vertices[c];

	vab = FMath::Lerp(va, vb, 0.5);
	vbc = FMath::Lerp(vb, vc, 0.5);
	vca = FMath::Lerp(vc, va, 0.5);



	// custom noise...
	//vab = vab + FVector(0,0,7);
	//vbc = vbc + FVector(0, 0, 7);
	//vca = vca + FVector(0, 0, 7);
	



	/*
	if (DisplacePoints.Num() > 0)
	{
		for (int i = 0; i < DisplacePoints.Num(); i++)
		{
			if (FVector(va + GetActorLocation() - DisplacePoints[i]).Size() < DistFromPoint)
			{
				va = va * NoiseScale;
			}
			if (FVector(vb + GetActorLocation() - DisplacePoints[i]).Size() < DistFromPoint)
			{
				vb = vb * NoiseScale;
			}
			if (FVector(vc + GetActorLocation() - DisplacePoints[i]).Size() < DistFromPoint)
			{
				vc = vc * NoiseScale;
			}

			if (FVector(vab + GetActorLocation() - DisplacePoints[i]).Size() < DistFromPoint)
			{
				vab = vab * NoiseScale;
			}
			if (FVector(vbc + GetActorLocation() - DisplacePoints[i]).Size() < DistFromPoint)
			{
				vbc = vbc * NoiseScale;
			}
			if (FVector(vca + GetActorLocation() - DisplacePoints[i]).Size() < DistFromPoint)
			{
				vca = vca * NoiseScale;
			}
		}
	}
	*/
	

	// custom noise...
	//vab = vab * TerrainScale;
	//vbc = vbc * TerrainScale;
	//vca = vca * TerrainScale;
	

	Vertices_New.Add(va);
	Vertices_New.Add(vab);
	Vertices_New.Add(vca);

	Vertices_New.Add(vca);
	Vertices_New.Add(vbc);
	Vertices_New.Add(vc);

	Vertices_New.Add(vab);
	Vertices_New.Add(vb);
	Vertices_New.Add(vbc);

	Vertices_New.Add(vab);
	Vertices_New.Add(vbc);
	Vertices_New.Add(vca);


	IndexA = IndexA + 3;
	IndexB = IndexB + 3;
	IndexC = IndexC + 3;

}

void ATerrain::BuildTriangleList()
{

	for (int i = 0; i < Vertices.Num(); i++)
	{
		// Build vertecx index list
		Triangles.Add(i);
	}
}

void ATerrain::HandleSubdivision()
{
	// Keep subdivisions at a safe level! 
	if (Recursions > 5)
	{
		Recursions = 5;
	}
		// Start from base
		Vertices = { FVector(-TerrainScale, -TerrainScale, TerrainScale),
			FVector(-TerrainScale, TerrainScale, TerrainScale),
			FVector(TerrainScale, -TerrainScale, TerrainScale),
			FVector(TerrainScale, TerrainScale, TerrainScale) };
	

		Triangles = { 0,1,2,2,1,3 };


	


	// Handle the subdivisions
	for (int i = 0; i < Recursions; i++)
	{

		for (int j = 0; j < Triangles.Num() / 3; j++)
		{

			Subdivide(Triangles[IndexA], Triangles[IndexB], Triangles[IndexC]);
		}

		// Empty
		Vertices.Empty();
		Triangles.Empty();



		//Assign new to current
		Vertices = Vertices_New;


		//New empty 
		Vertices_New.Empty();
		VertexColors.Empty();

		//Build tri indices
		BuildTriangleList();


		//Reset index counters 
		IndexA = 0;
		IndexB = 1;
		IndexC = 2;


	}

	//TerrainMesh->CreateMeshSection_LinearColor(0, Vertices, Triangles, Normals, UV0, VertexColors, Tangents, true);
	//TerrainMesh->SetWorldLocation(RootComponent->GetComponentLocation() + (GetActorUpVector() / -1) * TerrainScale);
}


void ATerrain::CheckPlayerInBounds()
{
	/*
	if (PlayerPos.X < TerrainMesh->GetComponentLocation().X + TerrainScale&&
		PlayerPos.X > TerrainMesh->GetComponentLocation().X - TerrainScale &&
		PlayerPos.Y < TerrainMesh->GetComponentLocation().Y + TerrainScale &&
		PlayerPos.Y > TerrainMesh->GetComponentLocation().Y - TerrainScale)
	{
		InBounds = true;
	}
	else
	{
		InBounds = false;
	}
	*/

	if (FVector(PlayerPos - TerrainMesh->GetComponentLocation()).Size() < DistFromTerrain)
	{
		InBounds = true;
	}
	else
	{
		InBounds = false;
	}

}

void ATerrain::GetOuterEdges()
{
	ia = 0;
	ib = 1;
	ic = 2;


	// look for and add internal triangles
	for (int i = 0; i < Triangles.Num() / 3; i++)
	{
		FVector a, b, c, avg;

		a = Vertices[Triangles[ia]];
		b = Vertices[Triangles[ib]];
		c = Vertices[Triangles[ic]];

		avg = (a + b + c) / 3;
		avg = avg + TerrainLocation;

		// if X plane
		if (ZFace_Plane)
		{
			if (avg.X > GetActorLocation().X + (TerrainScale / DistanceFromEdgeBounds) ||
				(avg.X < GetActorLocation().X - (TerrainScale / DistanceFromEdgeBounds)) ||
				(avg.Y > GetActorLocation().Y + (TerrainScale / DistanceFromEdgeBounds)) ||
				(avg.Y < GetActorLocation().Y - (TerrainScale / DistanceFromEdgeBounds))) 
			{
				EdgeVertices.Add(a);
				EdgeVertices.Add(b);
				EdgeVertices.Add(c);
			}
		}
		ia = ia + 3;
		ib = ib + 3;
		ic = ic + 3;
	}

}



void ATerrain::DoNoise()
{
	// Check vertex distance from noise points
	for (int i = 0; i < Vertices.Num(); i++)
	{
		for (int j = 0; j < DisplacePoints.Num(); j++)
		{
			if (FVector(Vertices[i] + TerrainLocation - DisplacePoints[j]).Size() < DistFromPoint)
			{
				Vertices[i] = Vertices[i] * NoiseScale;
			}

		}

	}

	TerrainMesh->UpdateMeshSection(0, Vertices, Normals, UV0, UpVertexColors, Tangents);
}